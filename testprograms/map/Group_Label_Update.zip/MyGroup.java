
package com.adventnet.nms.mapui;

import com.adventnet.nms.mapui.DefaultMapModel;
import com.adventnet.nms.startclient.NmsFrame;
import com.adventnet.nms.mapui.MapClientAPI;
import com.adventnet.nms.util.CustomClassInterface;
import java.io.PrintStream;
import java.util.Properties;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.border.*;


public class MyGroup implements NmsFrame
{
    JApplet applet;
	private JFrame jf=null;
    public void init(JApplet app)
    {
        jf=new JFrame();
        jf.setBounds(0,0,200,200);
        jf.setVisible(false);
        applet = app;
        String groupName =applet.getParameter("groupName");//No Internationalisation
        String mapName =applet.getParameter("mapName");//No Internationalisation
		System.out.println("  Check the groupName "+groupName+" mapName "+mapName);
		
		MapClientAPI mapclientapi = new MapClientAPI();
		DefaultMapModel defaultmapmodel = mapclientapi.getMapModel(mapName);
		System.out.println("  Check the defaultmapmodel "+defaultmapmodel);
		
		MapGroupComponent mapGroup = new MapGroupComponent();
        mapGroup = defaultmapmodel.getGroupByName(groupName);
        Properties properties = new Properties();
        properties.setProperty("name", "Group");
        properties.setProperty("label", "Group");
	    defaultmapmodel.updateGroup(mapGroup.getKey(), properties, true);
		System.out.println("  Check the mapGroup "+mapGroup+" and mapGroup.getKey() "+mapGroup.getKey());
    }
    public void setVisible(boolean b)
	{
       jf.setVisible(b); 
    }
}
