package com.test;

import java.sql.*;
import com.adventnet.nms.topodb.IpAddress;

public  class ExtendedIpAddress extends com.adventnet.nms.topodb.IpAddress
{
	//<Begin_Variable_Declarations>
	private String sysDescr = "";
	private String sysContact = "";
	private String testip = "";
	//<End_Variable_Declarations>

  
 public void setSysDescr(String sysDescrArg)
  {
 //<Begin_setSysDescr_String> 
 if(sysDescrArg != null)
 {
	sysDescr = sysDescrArg;
 }
  
 //<End_setSysDescr_String>
  } 
  
 public String getSysDescr()
  {
         //<Begin_getSysDescr> 
	return sysDescr;
  
         //<End_getSysDescr>
  } 
  
 public void setSysContact(String sysContactArg)
  {
 //<Begin_setSysContact_String> 
 if(sysContactArg != null)
 {
	sysContact = sysContactArg;
 }
  
 //<End_setSysContact_String>
  } 
  
 public String getSysContact()
  {
         //<Begin_getSysContact> 
	return sysContact;
  
         //<End_getSysContact>
  } 
  
 public void setTestip(String testipArg)
  {
 //<Begin_setTestip_String> 
 if(testipArg != null)
 {
	testip = testipArg;
 }
  
 //<End_setTestip_String>
  } 
  
 public String getTestip()
  {
         //<Begin_getTestip> 
	return testip;
  
         //<End_getTestip>
  } 
  
  public java.util.Properties getProperties()
  {
         //<Begin_getProperties> 
	java.util.Properties mosource_prop;
	mosource_prop = super.getProperties();

	if(getSysDescr()!=null)
	{
		mosource_prop.put("sysDescr",getSysDescr());
	}
	if(getSysContact()!=null)
	{
		mosource_prop.put("sysContact",getSysContact());
	}
	if(getTestip()!=null)
	{
		mosource_prop.put("testip",getTestip());
	}
	return mosource_prop;
  
         //<End_getProperties>
  } 
  
  public void setProperties(java.util.Properties p)
  {
         //<Begin_setProperties_java.util.Properties> 

	String sysDescrvalue=p.getProperty("sysDescr");
	if(sysDescrvalue!=null)
	{ 
		sysDescr=sysDescrvalue;
		p.remove("sysDescr");
	} 

	String sysContactvalue=p.getProperty("sysContact");
	if(sysContactvalue!=null)
	{ 
		sysContact=sysContactvalue;
		p.remove("sysContact");
	} 

	String testipvalue=p.getProperty("testip");
	if(testipvalue!=null)
	{ 
		testip=testipvalue;
		p.remove("testip");
	} 
	super.setProperties( p);

  
         //<End_setProperties_java.util.Properties>
  } 
  
  public Object clone()
  {
         //<Begin_clone> 
	return super.clone();
  
         //<End_clone>
  } 
  
  public int checkStatus() throws java.rmi.RemoteException
  {
         //<Begin_checkStatus> 
	return super.checkStatus();
  
         //<End_checkStatus>
  } 
  public int checkDHCPNodeStatus()
  {
        System.out.println("Inside IpAddress checkDHCPNodeStatus avoiding dhcp poll :SUCCESS" );
       return pollStatusProceed;
  }

} 


