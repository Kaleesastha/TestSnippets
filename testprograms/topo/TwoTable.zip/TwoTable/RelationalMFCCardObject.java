package com.adventnet.nms.store.relational; 
import java.sql.*; 
import java.util.*; 
import com.adventnet.nms.store.*; 
import com.adventnet.management.transaction.PreparedStatementWrapper; 
import com.adventnet.nms.topodb.*;  

public class RelationalMFCCardObject extends RelationalManagedObject
{	
	static boolean initialized = false ; 
	static int psIDForGet; 
	static int psIDForAdd; 
	static int psIDForDelete; 
	static int psIDForUpdate; 
	
	public RelationalMFCCardObject() 
	{		
	}
	public void init(RelationalAPI relapi) 
	{		
		super.init(relapi); 
		if (initialized) return; 
		String prepareSqlStringForGet =  "select * from MFCCardObject where ( "
		 +"( " + RelationalUtil.getAlias( "name" ) + " = ? )"
		 +")"; 
		
		psIDForGet = relapi.getPreparedStatementID 
		( prepareSqlStringForGet ); 
		
		String prepareSqlStringForAdd =  "insert into MFCCardObject values ( "
		 +" ?,"
		 +" ?,"
		 +" ?,"
		 +" ?,"
		 +" ?,"
		 +" ?,"
		 +" ?,"
		 +" ?"
		 +" )"; 
		
		psIDForAdd = relapi.getPreparedStatementID 
		( prepareSqlStringForAdd ); 
		
		String prepareSqlStringForUpdate =  "update MFCCardObject set " + RelationalUtil.getAlias( "name" ) + " = ?," + RelationalUtil.getAlias( "slotNo" ) + " = ?," + RelationalUtil.getAlias( "redundancyState" ) + " = ?," + RelationalUtil.getAlias( "loaderVersion" ) + " = ?," + RelationalUtil.getAlias( "softwareRevision" ) + " = ?," + RelationalUtil.getAlias( "operationStatus" ) + " = ?," + RelationalUtil.getAlias( "fabInfo" ) + " = ?," + RelationalUtil.getAlias( "serialNo" ) + " = ?"
		 +" where ( "
		 +"( " + RelationalUtil.getAlias( "name" ) + " = ? )"
		 +")"; 
		
		psIDForUpdate = relapi.getPreparedStatementID 
		( prepareSqlStringForUpdate ); 
		
		String prepareSqlStringForDelete =  "delete from MFCCardObject where ( "
		 +"( " + RelationalUtil.getAlias( "name" ) + " = ? )"
		 +")"; 
		
		psIDForDelete = relapi.getPreparedStatementID 
		( prepareSqlStringForDelete ); 
		initialized=true; 
	}
	
	public boolean fillProperties(DBInterface dbObj, Properties p) 
	{		
		MFCCardObject obj = (MFCCardObject)dbObj; 
		if ( (p==null) || (p.getProperty("name")==null) )
		{			
			return false; 
		}
		obj.setName(p.getProperty("name"));  
		
		obj.setProperties(p); 
		return true; 
	}
	
	public Vector getStatementsForGet(String[] args) 
	{		
		Vector v =super.getStatementsForGet(args); 
		PreparedStatementWrapper ps = relapi.fetchPreparedStatement(psIDForGet); 
		PreparedStatement preparedStatementForGet = ps.getPreparedStatement(); 
		if (preparedStatementForGet!=null) 
		{			
			try 
			{				
				preparedStatementForGet.setString(1,args[0]);  
				
				v.addElement(ps); 
			}
			catch (SQLException sqle) 
			{				
				System.err.println("Exception setting prepared statement for " 
				+" MFCCardObject "+args[0]+":"+sqle); 
			}
		}
		return v; 
	}
	public Vector getCustomStatements(DBInterface dbObj,String[] args) 
	{		
		//User to fill custom sql statements if any required 
		return super.getCustomStatements(dbObj,args); 
	}
	public void fillCustomProperties(DBInterface dbObj,ResultSet rs,String str) 
	{		
		super.fillCustomProperties(dbObj,rs,str); 
	}
	public void fillCustomProperties(DBInterface dbObj,ResultSet rs,PreparedStatement prstmt) 
	{		
		super.fillCustomProperties(dbObj,rs,prstmt); 
	}
	public void fillCustomProperties(DBInterface dbObj,ResultSet rs,int id) 
	{		
		super.fillCustomProperties(dbObj,rs,id); 
	}
	public Vector getStatementsForAdd(DBInterface dbObj) 
	{		
		MFCCardObject obj = (MFCCardObject)dbObj; 
		Vector v =super.getStatementsForAdd(dbObj); 
		PreparedStatementWrapper ps = relapi.fetchPreparedStatement(psIDForAdd); 
		PreparedStatement preparedStatementForAdd = ps.getPreparedStatement(); 
		if (preparedStatementForAdd!=null) 
		{			
			Properties p = obj.getProperties(); 
			try 
			{				
				preparedStatementForAdd.setString(1,db2str(p.getProperty("name")));

				preparedStatementForAdd.setInt(2,Integer.parseInt(p.getProperty("slotNo")));

				preparedStatementForAdd.setString(3,db2str(p.getProperty("redundancyState")));

				preparedStatementForAdd.setString(4,db2str(p.getProperty("loaderVersion")));

				preparedStatementForAdd.setString(5,db2str(p.getProperty("softwareRevision")));

				preparedStatementForAdd.setString(6,db2str(p.getProperty("operationStatus")));

				preparedStatementForAdd.setString(7,db2str(p.getProperty("fabInfo")));

				preparedStatementForAdd.setString(8,db2str(p.getProperty("serialNo")));

				
				v.addElement(ps); 
			}
			catch (SQLException sqle) 
			{				
				System.err.println("Exception setting preparedStatement for " 
				+ " MFCCardObject :"+sqle); 
				sqle.printStackTrace(); 
			}
		}
		return v; 
	}
	public Vector getStatementsForDelete(DBInterface dbObj) 
	{		
		MFCCardObject obj = (MFCCardObject)dbObj; 
		Vector v =super.getStatementsForDelete(dbObj); 
		PreparedStatementWrapper ps = relapi.fetchPreparedStatement(psIDForDelete); 
		PreparedStatement preparedStatementForDelete = ps.getPreparedStatement(); 
		if (preparedStatementForDelete!=null) 
		{			
			try 
			{				
				preparedStatementForDelete.setString(1,db2str(obj.getName()));
				
				v.addElement(ps); 
			}
			catch (SQLException sqle) 
			{				
				System.err.println("Exception setting preparedStatement for " 
				+" MFCCardObject :"+sqle); 
			}
		}
		return v; 
	}
	public Vector getStatementsForUpdate(DBInterface dbObj) 
	{		
		MFCCardObject obj = (MFCCardObject)dbObj; 
		Vector v =super.getStatementsForUpdate(dbObj); 
		PreparedStatementWrapper ps = relapi.fetchPreparedStatement(psIDForUpdate); 
		PreparedStatement preparedStatementForUpdate = ps.getPreparedStatement(); 
		if (preparedStatementForUpdate!=null) 
		{			
			Properties p = obj.getProperties(); 
			try 
			{				
				preparedStatementForUpdate.setString(1,db2str(p.getProperty("name")));

				preparedStatementForUpdate.setInt(2,Integer.parseInt(p.getProperty("slotNo")));

				preparedStatementForUpdate.setString(3,db2str(p.getProperty("redundancyState")));

				preparedStatementForUpdate.setString(4,db2str(p.getProperty("loaderVersion")));

				preparedStatementForUpdate.setString(5,db2str(p.getProperty("softwareRevision")));

				preparedStatementForUpdate.setString(6,db2str(p.getProperty("operationStatus")));

				preparedStatementForUpdate.setString(7,db2str(p.getProperty("fabInfo")));

				preparedStatementForUpdate.setString(8,db2str(p.getProperty("serialNo")));

				preparedStatementForUpdate.setString(9,db2str(p.getProperty("name")));

				
				v.addElement(ps); 
			}
			catch (SQLException sqle) 
			{				
				System.err.println("Exception setting preparedStatement for " 
				+" MFCCardObject :"+sqle); 
				sqle.printStackTrace(); 
			}
		}
		return v; 
	}
}
