package com.test;

import java.sql.*;
import com.adventnet.nms.topodb.SnmpInterface;


public  class ExtendedSnmpInterface extends com.adventnet.nms.topodb.SnmpInterface
{
	//<Begin_Variable_Declarations>
	private String sysContact = "";
	private String sysName = "";
	private String test = "";
	//<End_Variable_Declarations>

  
 public void setSysContact(String sysContactArg)
  {
 //<Begin_setSysContact_String> 
 if(sysContactArg != null)
 {
	sysContact = sysContactArg;
 }
  
 //<End_setSysContact_String>
  } 
  
 public String getSysContact()
  {
         //<Begin_getSysContact> 
	return sysContact;
  
         //<End_getSysContact>
  } 
  
 public void setSysName(String sysNameArg)
  {
 //<Begin_setSysName_String> 
 if(sysNameArg != null)
 {
	sysName = sysNameArg;
 }
  
 //<End_setSysName_String>
  } 
  
 public String getSysName()
  {
         //<Begin_getSysName> 
	return sysName;
  
         //<End_getSysName>
  } 
  
 public void setTest(String testArg)
  {
 //<Begin_setTest_String> 
 if(testArg != null)
 {
	test = testArg;
 }
  
 //<End_setTest_String>
  } 
  
 public String getTest()
  {
         //<Begin_getTest> 
	return test;
  
         //<End_getTest>
  } 
  
  public java.util.Properties getProperties()
  {
         //<Begin_getProperties> 
	java.util.Properties mosource_prop;
	mosource_prop = super.getProperties();

	if(getSysContact()!=null)
	{
		mosource_prop.put("sysContact",getSysContact());
	}
	if(getSysName()!=null)
	{
		mosource_prop.put("sysName",getSysName());
	}
	if(getTest()!=null)
	{
		mosource_prop.put("test",getTest());
	}
	return mosource_prop;
  
         //<End_getProperties>
  } 
  
  public void setProperties(java.util.Properties p)
  {
         //<Begin_setProperties_java.util.Properties> 

	String sysContactvalue=p.getProperty("sysContact");
	if(sysContactvalue!=null)
	{ 
		sysContact=sysContactvalue;
		p.remove("sysContact");
	} 

	String sysNamevalue=p.getProperty("sysName");
	if(sysNamevalue!=null)
	{ 
		sysName=sysNamevalue;
		p.remove("sysName");
	} 

	String testvalue=p.getProperty("test");
	if(testvalue!=null)
	{ 
		test=testvalue;
		p.remove("test");
	} 
	super.setProperties( p);

  
         //<End_setProperties_java.util.Properties>
  } 
  
  public Object clone()
  {
         //<Begin_clone> 
	return super.clone();
  
         //<End_clone>
  } 
  
  public int checkStatus() throws java.rmi.RemoteException
  {
         //<Begin_checkStatus> 
	return super.checkStatus();
  
         //<End_checkStatus>
  } 
  public int checkDHCPNodeStatus()
  {
 System.out.println("Inside SnmpInterface checkDHCPNodeStatus avoiding dhcp poll :SUCCESS" );
       return pollStatusProceed;
  }

} 


