package test;

import javax.swing. *;
import java.util. *;
import java.awt. *;
import java.awt.event. *;
import javax.swing.tree.*;
import javax.swing.event.*;

import com.adventnet.nms.util.*;
import com.adventnet.nms.mapui.*;
import com.adventnet.nms.severity.*;


public class ClientAPIExample implements  TreeSelectionListener, ListSelectionListener, ActionListener, MapListener
{
	com.adventnet.nms.mapui.MapClientAPI  myAPI = null;	
	JFrame frame;
	JTree tree;
	JScrollPane treePane;
	JScrollPane scrollPane;
	DefaultMapModel DMModel;
	Vector symbols;
	JPanel pan = new JPanel();
	Properties prop = new Properties();
	String selectedNode = null;
	String currentMapViewed = null;
	JCheckBoxMenuItem saveCheckBox = null;
	boolean saveAllTheChanges = false;
	String objectName = "test-";
	static int objectCount = 0;

	public ClientAPIExample()
	{
		myAPI = com.adventnet.nms.mapui.MapClientAPI.getInstance();	
		DefaultTreeModel model = myAPI.getMapNames();
		
				frame = new JFrame();
		tree = new JTree(model);
		//tree.setRootVisible(false);
		scrollPane = new JScrollPane(pan);
		tree.addTreeSelectionListener(this);
		treePane = new JScrollPane(tree);
		treePane.setMinimumSize(new Dimension(150,300));
		frame.getContentPane().add(treePane,BorderLayout.WEST);
		frame.setSize(800,600);
		frame.getContentPane().add(scrollPane,BorderLayout.CENTER);
		//frame.getContentPane().add(pan,BorderLayout.CENTER);

		createMenuBar();
		frame.setVisible(true);
	}

	private void createMenuBar()
	{
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		JMenu menu = new JMenu("Map Views ");
		menuBar.add(menu);
		JMenuItem item;
		/*
		JMenuItem item = new JMenuItem("Add Custom Map");
		menu.add(item);
		item.addActionListener(this);
		*/
		item = new JMenuItem("Save Current Map");
		menu.add(item);
		item.addActionListener(this);
		item = new JMenuItem("Delete Current Map");
		menu.add(item);
		item.addActionListener(this);

		menu.addSeparator();
		saveCheckBox = new JCheckBoxMenuItem("Save Changes ");
		saveCheckBox.setActionCommand("Save Changes");
		saveCheckBox.addActionListener(this);
		menu.add(saveCheckBox);

		createMenu(menuBar,"Add");
		createMenu(menuBar,"Update");
		createMenu(menuBar,"Delete");

		menu = new JMenu("Others");
		menuBar.add(menu);
		item = new JMenuItem("Show Map Config");
		menu.add(item);
		item  = new JMenuItem("Open");
		menu.add(item);
		item.addActionListener(this);//;Listener(this);
                
	}

	public void changeMap(MapEvent e )
	{
		if(e.getEventType() == MapEvent.MODIFY_SYMBOLS)
		{
			MapSymbolComponent[] symbol = e.getObjects();
			if(symbol != null)
			{
				for(int i =0 ; i < symbol.length;i++)
				{
					if (currentMapViewed == null || ! currentMapViewed.equals(symbol[i].getMapName()))
						return;
					System.err.println("MODIFY symbol called for "+symbol[i]);	
					((JButton)prop.get(symbol[i].getName().trim())).setBackground(SeverityInfo.getInstance().getColor(symbol[i].getStatus()));
				}
			}
		}
		else if(e.getEventType() == MapEvent.ADD_SYMBOLS)
		{
			MapSymbolComponent[] symbol = e.getObjects();
			if(symbol != null)
			{
				for(int i =0 ; i < symbol.length;i++)
				{
					if (currentMapViewed == null || ! currentMapViewed.equals(symbol[i].getMapName()))
						return;
					if (symbol[i] instanceof MapLinkComponent)	
						return;
					JButton b = createButton(symbol[i]);
					pan.add(b);
					numSymbols++;
					prop.put(symbol[i].getName() , b );
				}
				refresh();
			}
		}
		else if(e.getEventType() == MapEvent.DELETE_SYMBOLS)
		{
			System.err.println("DELETE  ............");	
			MapSymbolComponent[] symbol = e.getObjects();
			if(symbol != null)
			{
				for(int i =0 ; i < symbol.length;i++)
				{
					if (currentMapViewed == null || ! currentMapViewed.equals(symbol[i].getMapName()))
						return;
					Component c[] = pan.getComponents();
					for(int j = 0;j < c.length;j++)
					{
						if(((JButton)c[j]).getText().trim().equals(symbol[i].getName()))
						{
							pan.remove((JButton)c[j]);
							numSymbols--;
						//		break;
						}
					}
				}
				refresh();
			}
		}
	}

private int numSymbols = 0;
private int rows = 1;
private int cols = 1;
java.awt.GridLayout gr;

	public void valueChanged(TreeSelectionEvent evt )
	{
		DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
		if (node == null) return;
		Object nodeInfo = node.getUserObject();
		selectedNode = (String) nodeInfo;
		//DMModel = myAPI.loadMap(selectedNode.trim());
		DMModel = myAPI.getMapModel(selectedNode.trim());

		if ( DMModel == null)
			DMModel = myAPI.loadMap(selectedNode.trim());
			
		if(DMModel != null)
		{
			currentMapViewed = selectedNode.trim();
			DMModel.addMapListener(this);
			symbols = DMModel.getSymbols();
			pan.removeAll();
			numSymbols = symbols.size();
			gr =  new java.awt.GridLayout();
			pan.setLayout(gr);
			JButton b;
			for(int j = 0;j<symbols.size();j++)
			{
				MapSymbolComponent mapsymbol = (MapSymbolComponent) symbols.elementAt(j);
				b = createButton(mapsymbol);
				pan.add(b);
				prop.put(((MapSymbolComponent)symbols.elementAt(j)).getName() , b );
			}
			refresh();
		}else
		{
			System.err.println("model is null ! ........" + selectedNode);
		}
	}

	public void valueChanged(ListSelectionEvent evt)
	{
		if (evt.getSource() instanceof JList)
		{
			JList list = (JList) evt.getSource();
			String selectedItem = (String) list.getSelectedValue();
			updatePropertyPanel(propsPanel,selectedItem);
		}
	}
	
	public void actionPerformed(ActionEvent evt)
	{
		String mapName = selectedNode;
		DefaultMapModel mapmodel = myAPI.getMapModel(mapName);
		
		if (evt.getActionCommand().equals("Add Custom Map"))
		{
				JOptionPane.showMessageDialog(null,"Not yet implemented ", "Result", JOptionPane.OK_OPTION);
		}
		if (evt.getActionCommand().equals("Save Current Map"))
		{
			boolean result = myAPI.saveMap(mapName);
			System.err.println("Result of save map " + mapName + " = " + result);
		}
		else if (evt.getActionCommand().equals("Delete Current Map"))
		{
			boolean result = myAPI.deleteMap(mapName);
			System.err.println("Result of delete map " + mapName + " = " + result);
		}
		else if (evt.getActionCommand().equals("Save Changes"))
		{
			saveAllTheChanges = saveCheckBox.getState();
		}

		else if (evt.getActionCommand().equals("AddSymbol"))
		{
			objectCount++;
			String name = "symbol-" + objectName + objectCount;
			addSymbol(name, mapmodel);
		}
		else if (evt.getActionCommand().equals("AddLink"))
		{
			objectCount++;
			MapSymbolComponent source = addSymbol("symbol-"+objectName+objectCount,mapmodel);
			objectCount++;
			MapSymbolComponent dest = addSymbol("symbol-"+objectName+objectCount,mapmodel);
			addLink(source.getName()+"---"+dest.getName(),source,dest,mapmodel);
		}
		else if (evt.getActionCommand().equals("AddGroup"))
		{
			objectCount++;
			addGroup("group-"+objectName+objectCount,mapmodel);
		}
		else if (evt.getActionCommand().equals("AddContainer"))
		{
			objectCount++;
			addContainer("container-"+objectName+objectCount,mapmodel);
		}
		//update need to be handled properly. These are only for temp. purpose
		else if (evt.getActionCommand().equals("UpdateSymbol"))
		{
			System.err.println("Update Symbol called .....");
			if (mapmodel != null)
			{
				String symbolName = "kumar_test_symbol";
				MapSymbolComponent symbol = mapmodel.getSymbolByName(symbolName);
				if (symbol != null)
				{
					Properties prop = new Properties();
					prop.put("label","kumar_updated_symbol"); 
					mapmodel.updateSymbol(symbolName+"\t"+"ipnet.netmap",prop,true);
					System.err.println("symbol updated " + symbolName);
				}
			}
		}
		else if (evt.getActionCommand().equals("UpdateLink"))
		{
			System.err.println("Update Link called .....");
			if (mapmodel != null)
			{
				String symbolName = "kumar_test_link1";
				MapSymbolComponent symbol = mapmodel.getLinkByName(symbolName);
				if (symbol != null)
				{
					Properties prop = new Properties();
					prop.put("label","kumar_updated_link1"); 
					mapmodel.updateLink(symbolName+"\t"+"ipnet.netmap",prop,true);
					System.err.println("link updated " + symbolName);
				}
			}
		}
		else if (evt.getActionCommand().equals("UpdateGroup"))
		{
			System.err.println("Update Group called .....");
			if (mapmodel != null)
			{
                            //	String symbolName = "kumar_test_group";
                            String symbolName = "Group2";
				MapSymbolComponent symbol = (MapSymbolComponent)getGroupByName(symbolName,mapmodel);
				if (symbol != null)
				{
					Properties prop = new Properties();
					prop.put("label","kumar_updated_group"); 
					boolean result = mapmodel.updateGroup(symbolName+"\t"+"ipnet.netmap",prop,true);
					System.err.println("group updated " + result);
                                        try
                                        {
                                        Thread test = new Thread();
                                        test.sleep(10000);
                                        }
                                        catch(Exception err)
                                        {}
                                        result = mapmodel.deleteGroup((MapGroupComponent)symbol);
                                        System.out.println("group is deleted "+result);
				}
                                
                               
			}
		}
		else if (evt.getActionCommand().equals("UpdateContainer"))
		{
			System.err.println("Update Container called .....");
			if (mapmodel != null)
			{
				String symbolName = "kumar_test_container";
				MapSymbolComponent symbol = mapmodel.getSymbolByName(symbolName);
				if (symbol != null)
				{
					Properties prop = new Properties();
					prop.put("label","kumar_updated_container"); 
					mapmodel.updateContainer(symbolName+"\t"+"ipnet.netmap",prop,true);
					System.err.println("container updated " + symbolName);
				}
			}
		}






                
                else if (evt.getActionCommand().equals("DeleteSymbol"))
		{
			System.err.println("Delate symbol called .....");
			if (mapmodel != null)
			{
				String symbolName = "advrouter";
				MapSymbolComponent symbol = mapmodel.getSymbolByName(symbolName);
				if (symbol != null)
				{
					mapmodel.deleteSymbol(symbol);
					System.err.println("symbol deleted " + symbolName);
				}
			}
		}




                

		else if (evt.getActionCommand().equals("Show Map Config"))
		{
			showConfigPanel();
		}
                else if(evt.getActionCommand().equals("Open"))
                {
                    myAPI.openMap("RouterMap.netmap");
                }
                
	}

	private MapSymbolComponent addSymbol(String name, DefaultMapModel mapmodel)
	{
		System.err.println("Add Symbol called .....");
		MapSymbolComponent symbol = new MapSymbolComponent();
		symbol.setName(name);
		symbol.setLabel(name);
                //	symbol.setObjName(name);
		symbol.setMenuName("nodemenu");
		symbol.setMapName(mapmodel.getMapName());
		if (mapmodel != null)
		{
			//mapmodel.addSymbol(symbol,true);
			boolean result = mapmodel.addSymbol(symbol,saveAllTheChanges);
			System.err.println("map symbol added into the model " + name + "	Result = " + result);
		}
		return symbol;
	}

	private MapLinkComponent addLink(String name,MapSymbolComponent source, MapSymbolComponent dest, DefaultMapModel mapmodel)
	{
		System.err.println("Add Link called .....");
		MapLinkComponent link = new MapLinkComponent();
		link.setName(name);
		link.setLabel(name);
                //	link.setObjName(name);
		link.setMenuName("linkmenu");
		link.setMapName(mapmodel.getMapName());
		link.setSourceObj(source);
		link.setSource(source.getName());
		link.setDestObj(dest);
		link.setDest(dest.getName());
		if (mapmodel != null)
		{
			mapmodel.addLink(link,saveAllTheChanges);
			System.err.println("map link added into the model: " + name);
		}
		return link;
	}
	
	private MapGroupComponent addGroup(String name, DefaultMapModel mapmodel)
	{
		System.err.println("Add Group called .....");
		MapGroupComponent group = new MapGroupComponent();
		group.setName(name);
		group.setLabel(name);
                //	group.setObjName(name);
		group.setMenuName("groupmenu");
		group.setMapName(mapmodel.getMapName());
		if (mapmodel != null)
		{
                       boolean result =  mapmodel.addGroup(group,saveAllTheChanges);
                       System.out.println("group has been added to the Map "+result);
			System.err.println("map group added into the model: " + name);
		}
		return group;
	}

	private MapContainerComponent addContainer(String name, DefaultMapModel mapmodel)
	{
		System.err.println("Add Container called .....");
		MapContainerComponent container = new MapContainerComponent();
		container.setName(name);
		container.setLabel(name);
		container.setObjName(name);
		container.setMenuName("nodemenu");
		container.setMapName(mapmodel.getMapName());
		if (mapmodel != null)
		{
			boolean result = mapmodel.addSymbol(container,saveAllTheChanges);
			System.err.println("map container added into the model: " + name + "	Result = " + result);
		}
		return container;
	}
	
	private MapGroupComponent getGroupByName(String symbolName, DefaultMapModel mapmodel)
	{
	 	Vector groups =  mapmodel.getGroups();
		for (int i=0; i<groups.size();i++)
		{
			MapGroupComponent group = (MapGroupComponent) groups.elementAt(i);
			if (symbolName.equals(group.getName()))
				return group;
		}
		return null;
	}

	private JButton createButton(MapSymbolComponent mapsymbol)
	{
		JButton b = new JButton();
		b.setText(mapsymbol.getName());
		b.setIcon(new ImageIcon(myAPI.loadImage(mapsymbol.getIconName())));
		b.setVerticalTextPosition(SwingUtilities.BOTTOM);
		b.setHorizontalTextPosition(SwingUtilities.CENTER);
		b.setToolTipText(mapsymbol.getName());
		Color c = SeverityInfo.getInstance().getColor(mapsymbol.getStatus());
		b.setBackground(c);
		b.setMinimumSize(new Dimension(100,100));
		b.setPreferredSize(new Dimension(100,100));
		return b;
	}

	private void refresh()
	{
			cols = (int) Math.ceil(Math.sqrt(numSymbols));
			rows = cols-1;  
			if ( (cols*rows) < numSymbols )  rows = cols; 
			gr.setColumns(cols);
			gr.setRows(rows);
			pan.validate();
			pan.invalidate();
			pan.repaint();
			scrollPane.validate();
			scrollPane.invalidate();
	}


	//complete this for showing all type and corresponding properties
	JPanel propsPanel = new JPanel();
	private void showConfigPanel()
	{
		//Hashtable typeVsProps = NmsClientUtil.mapIconDataReader.propertiesTable;
		Hashtable typeVsProps = NmsClientUtil.mapIconDataReader.getTypeVsProperties();

		if (typeVsProps == null || typeVsProps.size() == 0 )
		{
			JOptionPane.showMessageDialog(null,"No MapConfig data available ", "Message",
													JOptionPane.OK_OPTION);
			return;
		}

		JPanel typesPanel = new JPanel();
		JPanel configPanel = new JPanel(new BorderLayout());
		
		Enumeration e = typeVsProps.keys();
		Vector v = new Vector();
		while(e.hasMoreElements())
		{
			v.addElement(e.nextElement());
		}
		JList typesList = new JList(v);	
		typesList.addListSelectionListener(this);
		JScrollPane listPane = new JScrollPane(typesList);
		typesPanel.add(listPane);
		typesPanel.setMinimumSize(new Dimension(75,150));

		configPanel.add(typesPanel,BorderLayout.WEST);
		configPanel.add(propsPanel,BorderLayout.CENTER);
		//configPanel.add(propsPanel,BorderLayout.EAST);

		JDialog dialog = new JDialog();
		dialog.getContentPane().add(configPanel);
		dialog.setSize(500,160);
		dialog.show();
	}
	
	GridBagLayout gridbag = new GridBagLayout();
	GridBagConstraints c = new GridBagConstraints();

	private void updatePropertyPanel(JPanel propsPanel, String selectedItem)
	{
		propsPanel.removeAll();
		propsPanel.setLayout(gridbag);
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 0.5;
		c.weighty = 0.5;

		c.gridwidth=1;
		c.gridheight=1;

		Properties props = myAPI.getMapConfig(selectedItem);

		if (props != null && props.size() > 0)
		{
			for (Enumeration e=props.propertyNames();e.hasMoreElements();)
			{
				c.gridx=0;
				String key = (String) e.nextElement();
				JLabel keyLabel = createLabel(key);
				gridbag.setConstraints(keyLabel, c);
				//add into the panel
				propsPanel.add(keyLabel);
				c.gridx=1;
				//c.gridwidth = GridBagConstraints.REMAINDER;
				JLabel valueLabel = createLabel((String)props.getProperty(key));
				gridbag.setConstraints(valueLabel, c);
				//add into the panel
				propsPanel.add(valueLabel);
				c.gridy=c.gridy+1;
				//c.gridwidth = GridBagConstraints.RELATIVE;
			}
		}
		propsPanel.validate();
		//propsPanel.repaint();
	}

	private JLabel createLabel(String value)
	{
		JLabel label = new JLabel(value);
		label.setBackground(Color.white);
		return label;
	}
	
	private void createMenu(JMenuBar menuBar, String actionString)
	{
		JMenu menu = new JMenu(actionString);
		menuBar.add(menu);

		JMenuItem item = new JMenuItem("Symbol");
		item.setActionCommand(actionString+"Symbol");
		item.addActionListener(this);
		menu.add(item);

		item = new JMenuItem("Link");
		item.setActionCommand(actionString+"Link");
		item.addActionListener(this);
		menu.add(item);

		item = new JMenuItem("Group");
		item.setActionCommand(actionString+"Group");
		item.addActionListener(this);
		menu.add(item);

		item = new JMenuItem("Container");
		item.setActionCommand(actionString+"Container");
		item.addActionListener(this);
		menu.add(item);

	}
}



