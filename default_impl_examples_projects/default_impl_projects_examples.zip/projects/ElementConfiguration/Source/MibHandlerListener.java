//$Id: MibHandlerListener.java,v 1.1 2006/08/29 13:56:51 build Exp $

package com.adventnet.nms.config;

import java.util.*;

public interface MibHandlerListener
{
	public void setResult(Properties data);
}
