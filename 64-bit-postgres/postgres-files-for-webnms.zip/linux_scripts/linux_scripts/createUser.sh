#!/bin/sh
if [ $# = 5 ]
then
	PGSQL_HOME=$1
	PGSQL_SERVERNAME=$2
	PGSQL_PORT=$3
	PGSQL_USERNAME=$4
	DB_USERNAME=$5
else
	echo Usage : sh createUser.sh PGSQL_HOME PGSQL_SERVERNAME PGSQL_PORT PGSQL_USERNAME ROLE_NAME
	exit;
fi

FILEOWNER="`ls -l $PGSQL_HOME/ | grep "data" | awk '{print $3}'`"

COMM="`id |cut -d '=' -f2|cut -d '(' -f1`"

if [ $COMM != "0" ]
then
	$PGSQL_HOME/bin/createuser -p $PGSQL_PORT -U $PGSQL_USERNAME -h $PGSQL_SERVERNAME -P $DB_USERNAME
else
	su -p $FILEOWNER -c "$PGSQL_HOME/bin/createuser -U $PGSQL_USERNAME -p $PGSQL_PORT -h $PGSQL_SERVERNAME -P $DB_USERNAME"
fi
#$Id: createUser.sh,v 1.8 2011/04/07 10:03:29 prabakaran Exp $

