// class to test extension of Events.
// Contains two more Extended fields from Event

package com.adventnet.nms.eventdb;

import java.util.Properties;

public class MyEvent extends Event
{
	private String myProp1,myProp2,myProp3,myProp4,myProp5,myProp6,myProp7,myProp8,myProp9,myProp10,myProp11,myProp12,myProp13,myProp14;

	public MyEvent()
	{
        
	}

	public void setProperties(Properties prop)
	{
		myProp1 = (String) prop.remove("myProp1");
		myProp2 = (String) prop.remove("myProp2");
		myProp3 = (String) prop.remove("myProp3");
		myProp4 = (String) prop.remove("myProp4");
		myProp5 = (String) prop.remove("myProp5");
		myProp6 = (String) prop.remove("myProp6");
		myProp7 = (String) prop.remove("myProp7");
		myProp8 = (String) prop.remove("myProp8");
		myProp9 = (String) prop.remove("myProp9");
		myProp10 = (String) prop.remove("myProp10");
		myProp11 = (String)prop.remove("myProp11");
		myProp12=(String)prop.remove("myProp12");
		myProp13=(String)prop.remove("myProp13");
		myProp14=(String)prop.remove("myProp14");
		super.setProperties(prop);
	}

	public Properties getProperties()
	{
		Properties prop = super.getProperties();
		if(myProp1 != null)
			prop.put("myProp1",myProp1);
		if(myProp2 != null)
			prop.put("myProp2",myProp2);
		if(myProp3 != null)
			prop.put("myProp3",myProp3);
		if(myProp4 != null)
			prop.put("myProp4",myProp4);
		if(myProp5 != null)
			prop.put("myProp5",myProp5);
		if(myProp6 != null)
			prop.put("myProp6",myProp6);
		if(myProp7 != null)
			prop.put("myProp7",myProp7);
		if(myProp8 != null)
			prop.put("myProp8",myProp8);
		if(myProp9 != null)
			prop.put("myProp9",myProp9);
		if(myProp10 != null)
			prop.put("myProp10",myProp10);
		if(myProp11 != null)
			prop.put("myProp11",myProp11);
		if(myProp12 != null)
			prop.put("myProp12",myProp12);
		if(myProp13 != null)
			prop.put("myProp13",myProp13);
		if(myProp14 != null)
			prop.put("myProp14",myProp14);

		return prop;
	}

	public int getId()
	{
		return super.getId();
	}

	public void setId(int id)
	{
		super.setId(id);
	}

	public String getOwnerName()
	{
		return super.getOwnerName();
	}

	public void setOwnerName(String ownerName)
	{
		super.setOwnerName(ownerName);
	}

	public String getMyProp1()
	{
		return myProp1;
	}

	public void setMyProp1(String myProp1)
	{
		this.myProp1 = myProp1;
	}

	public String getMyProp2()
	{
		return myProp2;
	}

	public void setMyProp2(String myProp2)
	{
		this.myProp2 = myProp2;
	}
	public String getMyProp3()
	{
		return myProp3;
	}
	public void setMyProp3(String myProp3)
	{
		this.myProp3 = myProp3;
	} 
	public String getMyProp4()
	{
		return myProp4;
	}
	public void setMyProp4(String myProp4)
	{
		this.myProp4 = myProp4;
	} 
	public String getMyProp5()
	{
		return myProp5;
	}
	public void setMyProp5(String myProp5)
	{
		this.myProp5 = myProp5;
	}  
	public String getMyProp6()
	{
		return myProp6;
	}
	public void setMyProp6(String myProp6)
	{
		this.myProp6 = myProp6;
	}  

	public String getMyProp7()
	{
		return myProp7;
	}
	public void setMyProp7(String myProp7)
	{
		this.myProp7 = myProp7;
	}  
	public String getMyProp8()
	{
		return myProp8;
	}
	public void setMyProp8(String myProp8)
	{
		this.myProp8 = myProp8;
	}  
	public String getMyProp9()
	{
		return myProp9;
	}
	public void setMyProp9(String myProp9)
	{
		this.myProp9 = myProp9;
	}  

	public String getMyProp10()
	{
		return myProp10;
	}
	public void setMyProp10(String myProp10)
	{
		this.myProp10 = myProp10;
	}

	public String getMyProp11()
	{
		return myProp11;
	}
	public void setMyProp11(String myProp11)
	{
		this.myProp11 = myProp11;
	}

	public String getMyProp12()
	{
		return myProp12;
	}
	public void setMyProp12(String myProp12)
	{
		this.myProp12 = myProp12;
	}

	public String getMyProp13()
	{
		return myProp13;
	}
	public void setMyProp13(String myProp13)
	{
		this.myProp13 = myProp13;
	}
	public String getMyProp14()
	{
		return myProp14;
	}
	public void setMyProp14(String myProp14)
	{
		this.myProp14 = myProp14;

	}
}	
