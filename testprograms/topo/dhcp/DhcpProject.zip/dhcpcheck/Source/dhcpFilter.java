package com.test;

import com.adventnet.nms.topodb.ManagedObject;
import com.adventnet.nms.topodb.TopoAPI;
import com.adventnet.nms.util.NmsUtil;
import com.adventnet.management.transaction.*;
import com.adventnet.management.ManagementServer;
import com.adventnet.studio.services.filters.ManagementServerUtility;
import com.adventnet.nms.topodb.TopoObject;
import com.adventnet.nms.util.PureUtils;
import java.io.*;

import com.adventnet.nms.topodb.IpAddress;
import com.adventnet.nms.topodb.SnmpInterface ;

public class dhcpFilter implements com.adventnet.nms.topodb.FoundFilter
{
	//<Begin_Variable_Declarations>
	private TransactionAPI transactionAPI = null;
	private ManagementServerUtility managementServerUtility = null;
	//<End_Variable_Declarations>

        public ManagedObject filterObject(ManagedObject managedObject,TopoAPI topoApi) throws com.adventnet.management.transaction.UserTransactionException, com.adventnet.nms.store.NmsStorageException
        {
             	    System.out.println(" ****************** Inside discovery filter ******************");
                     if(managedObject instanceof TopoObject)
                {
                     
	String ip =((TopoObject)managedObject).getIpAddress();
		    System.out.println(" ip of topo mo = " + ip);
	if (ip.equals("192.168.201.3") || ip.equals("192.168.201.4"))
	{
	    System.out.println("INNNNNNNNNNN DISC FILTER WITH IP = " + ip);
	}
	else
	{
	     	    System.out.println("DiscFitler: not in range hence returning");
	      return managedObject;
	}
                     }
                //<Begin_filterObject_ManagedObject_TopoAPI> 
                if(managedObject instanceof TopoObject)
                {
                        String targetHost = managedObject.getName();
                        int port = ((TopoObject)managedObject).getSnmpport();
                        String  targetPort = Integer.toString(port);
                        String community = ((TopoObject)managedObject).getCommunity();
                        setRequiredParameters( targetHost, targetPort, community ) ; 
                        if(transactionAPI == null)
                        {
                                initTransactionAPI();
                        }
                        beginTransaction();
                        String name = null;
                        boolean checkMO = false;
                        if((managedObject instanceof SnmpInterface))
                        {
                                //<UserCode_Begin_Criteria1_IF_START>
                                System.out.println("DiscFitler: SnmpInterface" + managedObject.getProperties());



                                //<UserCode_End_Criteria1_IF_START>


                                com.test.ExtendedSnmpInterface ExtendedSnmpInterface0 = null;
                                name = managedObject.getName();
                                try
                                {
                                        checkMO = topoApi.isManagedObjectPresent(name);
                                        if(!checkMO)
                                        {
                                                ExtendedSnmpInterface0 = new com.test.ExtendedSnmpInterface();
                                                ExtendedSnmpInterface0.setProperties(managedObject.getProperties());
                                                ExtendedSnmpInterface0.setName(name);
                                        }
                                        else
                                        {
                                                ExtendedSnmpInterface0 = (com.test.ExtendedSnmpInterface)topoApi.checkOut(name);
                                        }
                                }
                                catch( java.rmi.RemoteException re )
                                {
                                        System.err.println( "RemoteException while checking for the object in database : " + name );
                                }
                                catch(com.adventnet.nms.util.TimeoutException re )
                                {
                                        System.err.println( " Timeout Exception while checking for the object in database : " +  name);
                                }				
                                ExtendedSnmpInterface0.setIsDHCP(true);		
                                ExtendedSnmpInterface0.setPhysAddr((managedObject.getName()).substring((managedObject.getName()).indexOf("-")+1));		
                                ExtendedSnmpInterface0.setSysContact(managementServerUtility.getStringResult( "property_1", null));		
                                ExtendedSnmpInterface0.setSysName(managementServerUtility.getStringResult( "property_2", null));		
                                ExtendedSnmpInterface0.setSysOID(managementServerUtility.getStringResult( "property_3", null));		
                                ExtendedSnmpInterface0.setTest("ThisisIpAdd");
                                //<UserCode_Begin_Criteria1_PROPERTIES_FINISH>
                                if (true)
                                        return ExtendedSnmpInterface0;



                                //<UserCode_End_Criteria1_PROPERTIES_FINISH>

                                try
                                {
                                        if(!checkMO)
                                        {
                                                topoApi.addObject(ExtendedSnmpInterface0);
                                        }
                                        else
                                        {
                                                topoApi.updateObject( ExtendedSnmpInterface0, true , true );
                                        }
                                }
                                catch(java.rmi.RemoteException ex)
                                {
                                        System.err.println("RemoteException while adding/updating the object" + ExtendedSnmpInterface0.getName() );
                                        rollbackTransaction(ex);
                                }
                                catch( com.adventnet.nms.util.AccessDeniedException ex )
                                {
                                        System.err.println( " AccessDeniedException while updating the object : " + ExtendedSnmpInterface0.getName() );
                                        rollbackTransaction(ex);
                                }
                                catch( com.adventnet.nms.store.NmsStorageException  ex)
                                {
                                        System.err.println( " NmsStorageException while adding/updating the object : " + ExtendedSnmpInterface0.getName() );
                                        rollbackTransaction(ex);
                                }
                                catch( com.adventnet.management.transaction.UserTransactionException  ex)
                                {
                                        System.err.println( " UserTransactionException while adding/updating the object : " + ExtendedSnmpInterface0.getName() );
                                        rollbackTransaction(ex);
                                }
                                commitTransaction();
                                return managedObject;
                        }
                        //<UserCode_Begin_Criteria1_IF_END>




                        //<UserCode_End_Criteria1_IF_END>
                        if((managedObject instanceof IpAddress))
                        {
                                //<UserCode_Begin_Criteria2_IF_START>
                                System.out.println("DiscFitler: IpAddress" + managedObject.getProperties());



                                //<UserCode_End_Criteria2_IF_START>


                                com.test.ExtendedIpAddress ExtendedIpAddress0 = null;
                                name = managedObject.getName();
                                try
                                {
                                        checkMO = topoApi.isManagedObjectPresent(name);
                                        if(!checkMO)
                                        {
                                                ExtendedIpAddress0 = new com.test.ExtendedIpAddress();
                                                ExtendedIpAddress0.setProperties(managedObject.getProperties());
                                                ExtendedIpAddress0.setName(name);
                                        }
                                        else
                                        {
                                                ExtendedIpAddress0 = (com.test.ExtendedIpAddress)topoApi.checkOut(name);
                                        }
                                }
                                catch( java.rmi.RemoteException re )
                                {
                                        System.err.println( "RemoteException while checking for the object in database : " + name );
                                }
                                catch(com.adventnet.nms.util.TimeoutException re )
                                {
                                        System.err.println( " Timeout Exception while checking for the object in database : " +  name);
                                }				
                                ExtendedIpAddress0.setSysContact(managementServerUtility.getStringResult( "property_4", null));		
                                ExtendedIpAddress0.setSysDescr(managementServerUtility.getStringResult( "property_5", null));
                                //<UserCode_Begin_Criteria2_PROPERTIES_FINISH>

                                if (true)	return ExtendedIpAddress0;



                                //<UserCode_End_Criteria2_PROPERTIES_FINISH>

                                try
                                {
                                        if(!checkMO)
                                        {
                                                topoApi.addObject(ExtendedIpAddress0);
                                        }
                                        else
                                        {
                                                topoApi.updateObject( ExtendedIpAddress0, true , true );
                                        }
                                }
                                catch(java.rmi.RemoteException ex)
                                {
                                        System.err.println("RemoteException while adding/updating the object" + ExtendedIpAddress0.getName() );
                                        rollbackTransaction(ex);
                                }
                                catch( com.adventnet.nms.util.AccessDeniedException ex )
                                {
                                        System.err.println( " AccessDeniedException while updating the object : " + ExtendedIpAddress0.getName() );
                                        rollbackTransaction(ex);
                                }
                                catch( com.adventnet.nms.store.NmsStorageException  ex)
                                {
                                        System.err.println( " NmsStorageException while adding/updating the object : " + ExtendedIpAddress0.getName() );
                                        rollbackTransaction(ex);
                                }
                                catch( com.adventnet.management.transaction.UserTransactionException  ex)
                                {
                                        System.err.println( " UserTransactionException while adding/updating the object : " + ExtendedIpAddress0.getName() );
                                        rollbackTransaction(ex);
                                }
                                commitTransaction();
                                return managedObject;
                        }
                        //<UserCode_Begin_Criteria2_IF_END>




                        //<UserCode_End_Criteria2_IF_END>

                        //<UserCode_Begin_METHOD_FINISH>




                        //<UserCode_End_METHOD_FINISH>
                        commitTransaction();
                }
                return managedObject;
        
                //<End_filterObject_ManagedObject_TopoAPI>
        } 
        private void initTransactionAPI()
        {
                //<Begin_initTransactionAPI> 
                try
                {
                        transactionAPI = NmsUtil.relapi.getTransactionAPI();
                }
                catch(Exception ex)
                {
                        System.err.println("Exception in getting the handle of TransactionAPI "+ ex);
                }
        
                //<End_initTransactionAPI>
        } 
        private void beginTransaction()
        {
                //<Begin_beginTransaction> 
                try
                {
                        transactionAPI.begin();
                }
                catch(javax.transaction.NotSupportedException nse)
                {
                        System.err.println("Transactions not supported ");
                }
                catch(Exception ex)
                {
                        System.err.println("Exception in beginning the transaction "+ex);
                }
        
                //<End_beginTransaction>
        } 
        private void commitTransaction()
        {
                //<Begin_commitTransaction> 
                try
                {
                        transactionAPI.commit();
                }
                catch(Exception ex)
                {
                        System.err.println("Exception in committing the transaction "+ex);
                }
        
                //<End_commitTransaction>
        } 
        private void rollbackTransaction(Exception exception)
        {
                //<Begin_rollbackTransaction_Exception> 
                try
                {
                        transactionAPI.rollback(exception.getMessage());
                }
                catch(Exception ex)
                {
                        System.err.println("Exception in rolling back the transaction "+ex);
                }
        
                //<End_rollbackTransaction_Exception>
        } 
        public dhcpFilter( )
        {
                //<Begin_dhcpFilter> 
                managementServerUtility = new ManagementServerUtility();
        
                //<End_dhcpFilter>
        } 
        private void setRequiredParameters(String targetHost, String targetPort, String community)
        {
                //<Begin_setRequiredParameters_String_String_String> 
                managementServerUtility.setTargetHost( targetHost ) ;
                managementServerUtility.setTargetPort( targetPort ) ;
                managementServerUtility.setCommunity( community ) ;
                String webNmsHome = PureUtils.rootDir;
                webNmsHome = webNmsHome.replace(File.separatorChar,'/') ; 
                if( !webNmsHome.endsWith("/"))
                {
                        webNmsHome = webNmsHome+"/"; 
                }
                managementServerUtility.setUrlPrefix("file:///"+webNmsHome+"NetMonitor/build/dhcpcheck_ManagementServer.xml#%dhcpFilter%");
                ManagementServer managementServer = com.adventnet.management.ManagementServer.getInstance();
                managementServerUtility.setManagementServerInstance( managementServer ) ;
        
                //<End_setRequiredParameters_String_String_String>
        } 

} 



