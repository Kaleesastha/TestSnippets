
/*StartMapClientExample.java*/

package test;

import com.adventnet.nms.mapui.*;
import com.adventnet.nms.util.*;

import java.awt.event.*;
import javax.swing.*;

import java.util.*;

public class StartMapClientExample implements CustomClassInterface 
{

	public void setProperties(Properties[] args)
	{
		new ClientAPIExample();
	}
}
