#!/bin/sh

if [ $# = 1 -o $# = 2 ]
then
	NMS_HOME=$1

else
	echo Usage : sh initDB.sh NMS_HOME
	exit;
fi
PGSQL_HOME=$NMS_HOME/pgsql
PASSWORD_FILE=$PGSQL_HOME/scripts/$2

user_id=`id | awk '$1 ~ /uid=0/ {print "1"}'`
if [ x"${user_id}" = "x1" ]; then

USER_NAME=postgres

PATH=$PATH:/usr/sbin
export PATH

useradd $USER_NAME
groupadd $USER_NAME

mkdir $PGSQL_HOME/data
chown -R $USER_NAME:$USER_NAME $PGSQL_HOME/data
chown -R $USER_NAME:$USER_NAME $PGSQL_HOME/tmp

if [ $# = 2 ]
then
	su - $USER_NAME -c "$PGSQL_HOME/bin/initdb -D $PGSQL_HOME/data -E UTF-8 --locale=C -U postgres --pwfile=$PASSWORD_FILE"
	rm $PASSWORD_FILE
else
	su - $USER_NAME -c "$PGSQL_HOME/bin/initdb -D $PGSQL_HOME/data -E UTF-8 --locale=C -U postgres -W"
fi

else

	if [ $# = 2 ]
	then
		$PGSQL_HOME/bin/initdb -D $PGSQL_HOME/data -E UTF-8 --locale=C -U postgres --pwfile=$PASSWORD_FILE
		rm $PASSWORD_FILE
	else
		$PGSQL_HOME/bin/initdb -D $PGSQL_HOME/data -E UTF-8 --locale=C -U postgres -W
	fi

fi

#$Id: initDB.sh,v 1.8 2011/03/28 12:52:17 prabakaran Exp $
