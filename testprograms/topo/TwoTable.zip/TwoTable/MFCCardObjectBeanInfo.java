
/**
 * CardObjectBeanInfo.java
 */

package com.adventnet.nms.topodb;

import java.beans.*;
import java.lang.reflect.Method;

public class MFCCardObjectBeanInfo extends SimpleBeanInfo
{
	public BeanDescriptor getBeanDescriptor()
	{
		BeanDescriptor bd = new BeanDescriptor(beanClass);
		return bd;
	}
	public MethodDescriptor[] getMethodDescriptors()
	{
		try
		{
			Method getter = beanClass.getMethod("getName",null);
			MethodDescriptor gettermd = new MethodDescriptor(getter);
			gettermd.setShortDescription("0");
			
			Class c[] =  { new String().getClass() };
			Method setter = beanClass.getMethod("setName",c);
			MethodDescriptor settermd = new MethodDescriptor(setter);
			settermd.setShortDescription("1");

			MethodDescriptor md[] = { gettermd ,settermd } ;
			return md;
		}

		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
  
	public PropertyDescriptor[] getPropertyDescriptors()
	{
		try
		{
			PropertyDescriptor name = new PropertyDescriptor("name",beanClass);
			name.setDisplayName("PRIMARY KEY");
			name.setShortDescription("0");


			PropertyDescriptor slotNo = new PropertyDescriptor("slotNo",beanClass);
			slotNo.setShortDescription("1");

			PropertyDescriptor redundancyState = new PropertyDescriptor("redundancyState",beanClass);
			redundancyState.setShortDescription("2");

			PropertyDescriptor loaderVersion = new PropertyDescriptor("loaderVersion",beanClass);
			loaderVersion.setShortDescription("3");
			PropertyDescriptor softwareRevision = new PropertyDescriptor("softwareRevision",beanClass);
			softwareRevision.setShortDescription("4");
			PropertyDescriptor operationStatus = new PropertyDescriptor("operationStatus",beanClass);
			operationStatus.setShortDescription("5");
			PropertyDescriptor fabInfo = new PropertyDescriptor("fabInfo",beanClass);
			fabInfo.setShortDescription("6");
			PropertyDescriptor serialNo = new PropertyDescriptor("serialNo",beanClass);
			serialNo.setShortDescription("7");



			PropertyDescriptor pd[] = { name,slotNo,redundancyState,loaderVersion,softwareRevision,operationStatus,fabInfo,serialNo };
			return pd;
		}
		catch(IntrospectionException e)
		{
			e.printStackTrace();
			return null;
		}
	}
	private final static Class beanClass = MFCCardObject.class;
}
