/**
 *        EventTestMapApplet.java    balaji.r.  18-03-2002
 **/

package com.adventnet.nms.mapui;

import java.awt. *;
import java.awt.event. *;
import java.util.*;
import javax.swing. *;
import javax.swing.event. *;


public class EventTestMapApplet extends MapApplet
{
    public EventTestMapApplet()
    {
        System.out.println(" *****************************************************");
        System.out.println(" ***************** EVENT  TEST  **********************");
        System.out.println(" *****************************************************");
    } 
   
    public void changeMap(MapEvent evt)
	{
		DefaultMapModel currentModel = (DefaultMapModel) evt.getSource();

        if(evt.getEventType() == MapEvent.DELETE_SYMBOLS )
        {

            System.out.println(" DELETE_SYMBOLS ............ event fired   ");

            System.out.println(" Deleted OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }


        if(evt.getEventType() == MapEvent.ADD_SYMBOLS )
        {

            System.out.println(" ADD_SYMBOLS ............ event fired   ");

            System.out.println(" Added OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }


        if(evt.getEventType() == MapEvent.MODIFY_SYMBOLS )
        {

            System.out.println(" MODIFY_SYMBOLS ............ event fired   ");

            System.out.println(" Modified OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + " :  object .. : "+msc[i]);

            }
        }


        if(evt.getEventType() == MapEvent.DELETE_SYMBOLS )
        {

            System.out.println(" DELETE_SYMBOLS ............ event fired   ");

            System.out.println(" Deleted OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }


        if(evt.getEventType() == MapEvent.ADD_LINKS )
        {

            System.out.println(" ADD_LINKS ............ event fired   ");

            System.out.println(" ADD_LINKS  OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }


        if(evt.getEventType() == MapEvent.DELETE_LINKS )
        {

            System.out.println(" DELETE_LINKS ............ event fired   ");

            System.out.println(" DELETE_LINKS OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }


        if(evt.getEventType() == MapEvent.MODIFY_LINKS )
        {

            System.out.println(" MODIFY_LINKS ............ event fired   ");

            System.out.println(" MODIFY_LINKS OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }


        if(evt.getEventType() == MapEvent.ZOOM )
        {

            System.out.println(" ZOOM ............ event fired   ");
            /*
            System.out.println(" Deleted OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

                }*/
        }


        if(evt.getEventType() == MapEvent.MODEL_CHANGED )
        {

            System.out.println(" MODEL_CHANGED ............ event fired   ");
            /*
            System.out.println(" Deleted OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

                }*/
        }


        if(evt.getEventType() == MapEvent.ADD_GROUPS )
        {

            System.out.println(" ADD_GROUPS ............ event fired   ");

            System.out.println(" Added Group OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }


        if(evt.getEventType() == MapEvent.DELETE_GROUPS )
        {

            System.out.println(" DELETE_GROUPS ............ event fired   ");

            System.out.println(" Deleted Group OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }


        if(evt.getEventType() == MapEvent.MODIFY_GROUPS )
        {

            System.out.println(" MODIFY_GROUPS ............ event fired   ");

            System.out.println(" Modified Group OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }


        if(evt.getEventType() == MapEvent.ADD_GROUPLINKS )
        {

            System.out.println(" ADD_GROUPLINKS ............ event fired   ");

            System.out.println(" Added Group Link OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }


        if(evt.getEventType() == MapEvent.DELETE_GROUPLINKS )
        {

            System.out.println(" DELETE_GROUPLINKS ............ event fired   ");

            System.out.println(" Deleted GL  OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }



        if(evt.getEventType() == MapEvent.SYMBOLS_SELECTED )
        {

            System.out.println(" SYMBOLS_SELECTED ............ event fired   ");

            System.out.println(" SYMBOLS_SELECTED  OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }

        if(evt.getEventType() == MapEvent.CUT_SYMBOLS )
        {

            System.out.println(" CUT_SYMBOLS ............ event fired   ");

            System.out.println(" CUT_SYMBOLS  OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }

        if(evt.getEventType() == MapEvent.COPY_SYMBOLS )
        {

            System.out.println(" COPY_SYMBOLS ............ event fired   ");

            System.out.println(" COPY_SYMBOLS OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }

        if(evt.getEventType() == MapEvent.PASTE_SYMBOLS )
        {

            System.out.println(" PASTE_SYMBOLS ............ event fired   ");

            System.out.println(" PASTE_SYMBOLS OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }

        if(evt.getEventType() == MapEvent.UNDO_CUT )
        {

            System.out.println(" UNDO_CUT ............ event fired   ");

            System.out.println(" UNDO_CUT  OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }

        if(evt.getEventType() == MapEvent.UNDO_PASTE )
        {

            System.out.println(" UNDO_PASTE.......... event fired   ");

            System.out.println(" UNDO_PASTE  OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }

        if(evt.getEventType() == MapEvent.UNDO_MOVE )
        {

            System.out.println(" UNDO_MOVE ............ event fired   ");

            System.out.println(" UNDO_MOVE  OBJECTS  ");

            MapSymbolComponent[] msc  = evt.getObjects();
            for(int i=0 ; i < msc.length ; i++)
            {
                System.out.println(i + "  object ..  "+msc[i]);

            }
        }
    super.changeMap(evt);
    }


}
