//$Id: NmsProcess.java,v 1.2 2002/02/15 13:17:26 karthicks Exp $
 package com.adventnet.nms.simulation ; 


import java.util.*;
import java.rmi.RemoteException;

import com.adventnet.nms.util.RunProcessInterface;
import com.adventnet.nms.util.NmsUtil;
import com.adventnet.nms.util.NmsLogMgr;
import com.adventnet.management.log.Log;
import com.adventnet.nms.util.XMLNode;

import com.adventnet.nms.eventdb.EventAPI;
import com.adventnet.nms.eventdb.Event;
import com.adventnet.nms.eventdb.EventObserver;

import com.adventnet.nms.alertdb.AlertListener;
import com.adventnet.nms.alertdb.AlertActionInformer;
import com.adventnet.nms.alertdb.AlertAPI;
import com.adventnet.nms.alertdb.Alert;




public class NmsProcess implements RunProcessInterface, EventObserver, AlertListener
{
    private boolean initialized = false;
    
    // API's to register and used for notification.
    private EventAPI eAPI = null;
    private AlertAPI aAPI = null;
    
    // to keep track of Event counts
    private long eventCount=1;

    // to keep tract of Alert counts
    private long alertCount=1,oldAlertCount=1;
    
    // initialization parameter to determine for how many count the perf needs to be logged.
    private long eventDiffCount=500,alertDiffCount=500;


    // to keep track when event / Alert are last logged.
    private long tempEventTime,tempAlertTime;

       MultiplePerfCal multiple;

    private void init (String[] args)
	{
        try
        {
            multiple = new MultiplePerfCal("Alert",true);
            NmsUtil.bindObjectInRegistry(multiple,"AlertCount",true);
        }
        catch(Exception exp)
        {
            exp.printStackTrace();
        }
		// do process specific initialization
		for(int i=0;i<args.length;i++)
		{
			try
			{
				if(args[i].equalsIgnoreCase("EVENT_COUNT"))
				{
					eventDiffCount = Long.parseLong(args[++i]);
					continue;
				}
				if(args[i].equalsIgnoreCase("ALERT_COUNT"))
				{
					alertDiffCount = Long.parseLong(args[++i]);
					continue;
				}
			}
			catch(NumberFormatException nume)
			{
				NmsLogMgr.EVENTERR.fail("----------->Invalid entry for Event_count or Alert_count.  Please recheck.  Till then perf will be logged for every 500 counts",null);
			}
		}

	}

	private void proc()
	{
		// will try to get the EventAPI handle & AlertAPI handle and wait if EventAPI not binded.  This could be changed
		// not to wait infinite time.
		while(eAPI == null || aAPI == null)
		{
			getAPIHandle();
			try
			{
				Thread.sleep(2000);
			}
			catch(InterruptedException inte)
			{
			}
		}
		NmsLogMgr.EVENTUSER.log("--------->EventAPI and AlertAPI handles obtained . ",Log.SUMMARY);
		initialized = true;
		registerForNotifications();
	}


	/*  Helper method to register as TrapObserver.
	 */
	private void registerForNotifications()
	{
		try
		{
			eAPI.registerForEvents(this);
			aAPI.addAlertListener(this);
			NmsLogMgr.EVENTUSER.log("------------->Registered as Event and Alert Observer",Log.SUMMARY);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}


	/*  Helper method to obtain EventAPI handle.
	 */
	private void getAPIHandle()
	{
		if(eAPI == null)
		{
			eAPI = (EventAPI) NmsUtil.getAPI("EventAPI");
		}
		if(aAPI == null)
		{
			aAPI = (AlertAPI) NmsUtil.getAPI("AlertAPI");
		}
	}

	/*  This method should return 'true' after initialization of the process.
	 */
	public boolean isInitialized ()
	{
		return initialized;
	}


	/*  To handle shut Down.
	 */
	public void shutDown ()
	{
		// handle shutdown for the process

	}

	public void update(Event event)
	{
		if(eventCount == 1)
		{
			tempEventTime = System.currentTimeMillis();
		}
		if((eventCount % eventDiffCount) == 0)
		{
			printEventRate();
		}
		eventCount++;
	}

	public void update(XMLNode xmlnode)
	{
		try
		{
			NmsLogMgr.EVENTUSER.log("------------>Alert update notified with XML Node.",Log.SUMMARY);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void listenAlert(AlertActionInformer action) 
	{
		if(alertCount == 1)
		{
			tempAlertTime = System.currentTimeMillis();
		}
		if(action.isBatchUpdate())
		{
			Vector v = action.getAlertList();
			if(v.size() > 0)
			{
				alertCount += v.size();
			}	
		}
		else
		{
			Alert a = action.getAlert();
			alertCount += 1;
		}
		if((alertCount - oldAlertCount) >= alertDiffCount)
		{
			printAlertRate();
		}
	}

	private void printEventRate()
	{
		double tempInt = ((System.currentTimeMillis() - tempEventTime) / 1000d);
        
		NmsLogMgr.EVENTUSER.log("--------->Time taken to process last " + eventDiffCount + " events " + 
                                tempInt + " secs.  Processing rate : " + (eventDiffCount / tempInt)+ " per sec",Log.SUMMARY);
		tempEventTime = System.currentTimeMillis();
	}


	private void printAlertRate()
	{
	    double tempInt =  ((System.currentTimeMillis() - tempAlertTime) / 1000d);
	    multiple.startNextRun();
	    multiple.add("AlertCount",alertCount - oldAlertCount);
	    multiple.add("Seconds",(double)tempInt);
	    multiple.add("Rate",(double)((alertCount - oldAlertCount)/tempInt));
	    multiple.printRun();
	    NmsLogMgr.ALERTERR.fail("----------->Time taken to process last " + (alertCount - oldAlertCount) + " Alerts " + tempInt +
				    " secs.  Processing rate : " + ((alertCount - oldAlertCount) / tempInt) + " per sec ",null);
	    oldAlertCount=alertCount;
	    tempAlertTime = System.currentTimeMillis();
	}


	/*  This method will be called during start up of NMS server.
	 */
	public void callMain (String[] args)
	{
		// This method is called by the NMS server during startup.
		init(args);
		proc(); 
	}
} // End of class NmsProcess



