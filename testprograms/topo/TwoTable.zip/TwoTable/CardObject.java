/**
 * CardObject.java
 */

package com.adventnet.nms.topodb;

import java.util.*;
import java.net.*;
import java.io.*;

import com.adventnet.nms.util.WatchUtil;
import com.adventnet.nms.util.NmsLogMgr;
import com.adventnet.nms.util.NmsUtil;
import com.adventnet.util.NVProperties;

import com.adventnet.management.log.Log;

/** 
 * This class extends the ManagedObject class and is the base class for all
 * IP objects. It defines fields specific to Network Elements implementing
 * TCP/IP.
 */

/*
 * CORBA Note: (07\16\99 - Sreenivas)
 *    To support the Topology.IDL, this class implements the _TopoObject_CI 
 *    interface. 
 */
public class CardObject extends OmxManagedObject {

    /** 
     * The IP Address of the Network Element which may be the same as the name
     */
    private int slotNo  =1;

    /** 
     * Get the Ipaddress of the Network Element which may be the same as the name.
     * @return  The Ipaddress of the Network element.
     */ 
    public int  getSlotNo()
    {
        return slotNo;
    }

    /** 
     * Sets the IpAddress of the Network Element which may be the same as the name
     * @param   ipAddress  The Ipaddress of the Network element.
     */ 
    public void setSlotNo(int slotNo)
    {
        this.slotNo = slotNo;
    }

    /** 
     * Sub-net Mask of the Network Element
     */
    private String operationStatus= "";

    /** 
     * Get the Sub-net Mask of the Network Element.
     * @return  The sub netmask of the Network Element.
     */
    public String getOperationStatus()
    {
        return operationStatus;
    }

    /** 
     * Sets the Sub-net Mask of the Network Element
     * @param   netmask     The sub netmask of the Network Element.
     */  
    public void setOperationStatus(String operationStatus)
    {
        this. operationStatus=  operationStatus;
    }
	public String fabInfo="";
	
	 public String getFabInfo()
    {
        return fabInfo;
    }
	 public void setFabInfo(String fabInfo)
    {
        this.fabInfo=fabInfo;
    }
	 private String serialNo= "";

    /** 
     * Get the Sub-net Mask of the Network Element.
     * @return  The sub netmask of the Network Element.
     */
    public String getSerialNo()
    {
       return serialNo;
    }

    /** 
     * Sets the Sub-net Mask of the Network Element
     * @param   netmask     The sub netmask of the Network Element.
     */  
    public void setSerialNo(String serialNo)
    {
        this.serialNo= serialNo;
    }



    public void setProperties(Properties p) {
        Properties prop = p;

        if (p == null) {
            NmsLogMgr.TOPOUSER.log(NmsUtil.GetString("Error: Properties object is Null"),Log.INTERMEDIATE_DETAIL); 
            return;
        }

        String s;

        if ((s = p.getProperty("name")) != null)
        {
            if (!s.equals(getName())) {
                NmsLogMgr.TOPOUSER.log(NmsUtil.GetString("Error: Object Name cannot be changed"),Log.INTERMEDIATE_DETAIL); 
            }
            prop.remove("name");
        }

        if ((s = p.getProperty("slotNo")) != null) {
            slotNo =Integer.parseInt(s);prop.remove("slotNo");
        }    

        if ((s = p.getProperty("operationStatus")) != null)  {
            operationStatus= s;prop.remove(" operationStatus");
        }
		if ((s = p.getProperty("fabInfo")) != null)  {
            fabInfo = s;prop.remove(" fabInfo");
        }
		if ((s = p.getProperty("serialNo")) != null)  {
          serialNo = s;prop.remove("serialNo");
        }

	super.setProperties(prop);

	return;
    }  // end setProperties()

    /**
     * Returns the all the properties of the TopoObject.
     * Derived classes should override this method and invoke the
     * super.getProperties() in the begining of this method.
     *
     * @return  The values of following the fields of this class.
     * <pre>
     * <b>
     * 	name, ipAddress, netmask, isSNMP, isDHCP,  snmpport, baseMibs,
     *	community, writeCommunity, isInterface, isRouter, isNode, 
     *	isNetwork and all the properties of its super classes in a 
     *	Property object.
     * </b>
     * </pre>
     *
     * @see ManagedObject#getProperties()
     */
    public Properties getProperties() {
        // 07/16/99 - Sreenivas
        //    Return type changed to NVProperties (from Properties), to provide a 
        //    convenient way for getting the properties as a Property_CT[] (IDL defined data type). 
        NVProperties p = (NVProperties) super.getProperties();
        if (getName() != null) p.put("name", getName()); else p.put("name", "null");

        p.put("slotNo", new Integer(slotNo).toString());
        if (operationStatus!= null) p.put(" operationStatus",  operationStatus); else p.put(" operationStatus", "null");    	
		if (fabInfo != null) p.put("fabInfo", fabInfo); else p.put("fabInfo", "null");
		if (serialNo != null) p.put("serialNo", serialNo); else p.put("serialNo", "null");    	

        return p;
    } // end getProperties()


}	// End of class TopoObject

