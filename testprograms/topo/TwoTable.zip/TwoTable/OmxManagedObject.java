/**
 * CardObject.java
 */
package com.adventnet.nms.topodb;


import java.util.*;
import java.net.*;
import java.io.*;

import com.adventnet.nms.util.WatchUtil;
import com.adventnet.nms.util.NmsLogMgr;
import com.adventnet.nms.util.NmsUtil;
import com.adventnet.util.NVProperties;
import com.adventnet.nms.topodb.*;

import com.adventnet.management.log.Log;

/** 
 * This class extends the ManagedObject class and is the base class for all
 * IP objects. It defines fields specific to Network Elements implementing
 * TCP/IP.
 */

/*
 * CORBA Note: (07\16\99 - Sreenivas)
 *    To support the Topology.IDL, this class implements the _TopoObject_CI 
 *    interface. 
 */
public class  OmxManagedObject extends ManagedObject {


    public void setProperties(Properties p) {
        Properties prop = p;

        if (p == null) {
            NmsLogMgr.TOPOUSER.log(NmsUtil.GetString("Error: Properties object is Null"),Log.INTERMEDIATE_DETAIL); 
            return;
        }

        String s;

        if ((s = p.getProperty("name")) != null)
        {
            if (!s.equals(getName())) {
                NmsLogMgr.TOPOUSER.log(NmsUtil.GetString("Error: Object Name cannot be changed"),Log.INTERMEDIATE_DETAIL); 
            }
            prop.remove("name");
        }



	super.setProperties(prop);

	return;
    }  // end setProperties()

    /**
     * Returns the all the properties of the TopoObject.
     * Derived classes should override this method and invoke the
     * super.getProperties() in the begining of this method.
     *
     * @return  The values of following the fields of this class.
     * <pre>
     * <b>
     * 	name, ipAddress, netmask, isSNMP, isDHCP,  snmpport, baseMibs,
     *	community, writeCommunity, isInterface, isRouter, isNode, 
     *	isNetwork and all the properties of its super classes in a 
     *	Property object.
     * </b>
     * </pre>
     *
     * @see ManagedObject#getProperties()
     */
    public Properties getProperties() {
        // 07/16/99 - Sreenivas
        //    Return type changed to NVProperties (from Properties), to provide a 
        //    convenient way for getting the properties as a Property_CT[] (IDL defined data type). 
        NVProperties p = (NVProperties) super.getProperties();
        if (getName() != null) p.put("name", getName()); else p.put("name", "null");


        return p;
    } // end getProperties()


}	// End of class TopoObject

