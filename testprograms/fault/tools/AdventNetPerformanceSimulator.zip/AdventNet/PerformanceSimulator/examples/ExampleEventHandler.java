
package com.adventnet.nms.simulation ; 

import com.adventnet.nms.eventdb.*;
import java.util.*;
/**
 *       This example implements the interface com.adventnet.nms.simulation.EventHandler.
 *  When this class is registers as listener in Tool. Information of event to be 
 * generated will be given from tool.  This faciliates this example class to generate 
 * an Extended Event namely MyEvnt and returnsthat Event to tool. Tool will add 
 * that event using EventAPI.

 *       In order to use this example compile the MYEvent under classes directory 
 * of NMSHome. Using  Object to Relation Tool configure the DB to form separate table to 
 * handle Extended Event. Then compile this class under classes directory of the 
 * tool's Home. 
 */
public class ExampleEventHandler  implements EventHandler
{

    /** Class implementing EventHandler interface should have public Constructor.
     */
	public ExampleEventHandler()
	{


	}
	public  Event  formEvent(String source, String entity, int severity)
	{
	    Event evt = new MyEvent();
	    long lastTime = System.currentTimeMillis();
	    evt.setTime(lastTime);
	    evt.setEntity(entity);
	    evt.setSource(source);
	    evt.setSeverity(severity);
	    evt.setCategory("test");
	    //form extended event properties and set 
	    Properties prop = new Properties();
	    prop.put("myProp1","prop1");
	    prop.put("myProp2","prop2");
	    prop.put("myProp3","prop3");
	    prop.put("myProp4","prop4");
	    prop.put("myProp5","prop5");
	    prop.put("myProp6","prop6");
	    prop.put("myProp7","prop7");
	    prop.put("myProp8","prop8");
	    prop.put("myProp9","prop9");
	    prop.put("myProp10","prop10");
	    prop.put("myProp11","prop11");
	    prop.put("myProp12","prop12");
	    prop.put("myProp13","prop13");
	    prop.put("myProp14","prop14");
	    evt.setProperties(prop);
	    return evt;
	}
}







