package com.adventnet.nms.mapui;
import javax.swing.*;
import java.awt.event.*;
import java.awt.BorderLayout;
import javax.swing.event.*;
import java.util.Vector;
import java.util.*;
import java.util.Properties;
import javax.swing.border.*;
import java.awt.*;

import com.adventnet.nms.startclient.*;
import com.adventnet.nms.util.*;
import com.adventnet.nms.util.NmsPanelEventListener;
import com.adventnet.nms.util.NmsPanelEvent;
import com.adventnet.nms.mapui.*;
import com.adventnet.nms.mapdb.*;


public class ExampleNMSPanel extends AbstractBaseNmsPanel implements InternalFrameListener
{
    JMenuBar menuBar;
    JButton test = null;
	JPanel testPanel = null;
	public ExampleNMSPanel()
    {
        //super(false);
    }

    private void initLayout()
    {
		test = new JButton("Test");
		test.addActionListener(this);
		testPanel = new JPanel(new FlowLayout());
		testPanel.add(test);
        String message = "This is an Example of NmsPanel which demonstrates how NmsPanel can be integrated with NMS. In this panel you can design your own UI based on the requirement. The NmsPanel can be invoked from any of panel specific or object specific menu from the mapdata/menus or listmenus directory.";
        setLayout(new BorderLayout());
        JPanel pane1 = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        JTextArea textarea = new JTextArea(20,30);
        textarea.setFont(new Font("SansSerif",Font.BOLD,12));
        textarea.setText(message);
        JPanel top = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel msg = new JLabel("NmsPanel Example");
        top.setBorder(new EtchedBorder());
        top.add(msg);
        textarea.setEditable(false);
        textarea.setLineWrap(true);
        pane1.setBorder(new EtchedBorder());
        gbc.gridx=0; gbc.gridy=0;
        pane1.add(new JScrollPane(textarea),gbc);
        add(pane1,BorderLayout.CENTER);
        add(top,BorderLayout.NORTH);
		add(testPanel, BorderLayout.SOUTH);
		
        
    }
     public void internalFrameActivated(InternalFrameEvent e) 
                {
                    JInternalFrame jif = (JInternalFrame) e.getSource();
                    jif.setTitle("ExamplePanel ");
                }

	 public void init(Properties p)
	 {
	   for(Enumeration e = p.keys(); e.hasMoreElements();)
	   {
String value = "sasikumar s";
		 String key = (String)e.nextElement();
		 if(key != null)
		   value = (String)p.get(key);
		 else
		   System.out.println("NULLLLLLLLLLLL");

		 System.out.println(key+" :: "+value);
	   }
	   super.init(p);
	 }

    /** init method with Applet parameter */
    public void init(JApplet app)
    {
        initLayout();
    }

    public String key()
    {
        return "EXAMPLE_ID";
    }

    //just to populate this panel's specific menu data.
    // menusVector , This vector is to be initialized at startup. 
    private Vector menusVector = new Vector(5);

    //called from the Web NMS Client.  This will actually hold this
    //panel-specific menus.We shall update this menus from this in
    //our menuVector and return this when getPanelMenuBar is invoked.
    public void setPanelMenuBar (JMenuBar mb)
    {

         menuBar = mb;
		
        for(int i = 0;i<mb.getMenuCount();i++)
        {
            menusVector.addElement(mb.getMenu(i));
        }
        
    }

    //  This will return a MenuBar to be placed in the parent frame. This
    //  menubar will be shown when this panel is chosen.
    public JMenuBar getPanelMenuBar ()
    {
        
        int size = menusVector.size();
        for(int i = 0; i < size;i++)
        {
            JMenu m = ((JMenu)menusVector.elementAt(i));
            menuBar.add(m);
        }
        return menuBar ;
    }

    public void setProperties(Properties prop)
    {
            
        //String type = (String)prop.get("Type");

        //This is the ID specified in tree.xml corresponding
        //to this Device-ID otherwise it will be null.
        /*if(type == null)
        {
            return;
        }
        int index = tabPane.indexOfTab(type.trim()) ;
        index = (index >0 )?index : 0;
        tabPane.setSelectedIndex(index);*/
    }



    //Below methods of the interface NmsPanel are not implemented here.
    //As they are of no significance to us.
    public void start()
    {

    }

    public void stop()
    {
    }

    public void destroy()
    {
    }

    public void addNmsPanelEventListener(NmsPanelEventListener l)
    {
    }

    public void removeNmsPanelEventListener(NmsPanelEventListener l)
    {
    }

    public void fireNmsPanelEvent(NmsPanelEvent e)
    {
    }

    public void actionPerformed(ActionEvent e)
    {
        MapClientAPI mapAPI = MapClientAPI.getInstance();
		/*Hashtable p = getCurrentNodeProperties();
		for(Enumeration E = p.keys();E.hasMoreElements();)
		{
		 String key = (String)E.nextElement();
		 String value = "Sasikumar S";
		 if(key != null)
			 value = (String) p.get(key);

		System.out.println(key +" @@@ ::@@@  "+value);

		}*/
	  /*String id = "Example_id2";
	  Properties p = new Properties();
	  p.put("TREE-NAME","Example2");
	  p.put("PANEL-NAME","ExampleNmsPanel2");
	  boolean test = NmsUiAPI.addTreeNode("Network Database", id, p, false);
	  System.out.println(test);*/

	  

	MapContainerComponent mSym = new MapContainerComponent();
/*	MapSymbolComponent mSym = new MapSymbolComponent();*/

	mSym.setName("Sasicon");
	mSym.setLabel("Kumarcon");
	mSym.setObjName("clarence");
	mSym.setMenuName("snmpmenu.xml");
	mSym.setMapName("ipnet.netmap");

  	//System.out.println("Symbol added  "+model.addSymbol(mSym, true));

	//DefaultMapModel model = MapClientAPI.getInstance().getMapModel("ipnet.netmap");

        //System.out.println(MapClientAPI.getInstance().saveMap("Failed_Objects_Map.netmap"));
//	System.out.println(MapClientAPI.getInstance().getMapModel("Printers.netmap"));
//	System.out.println(MapClientAPI.getInstance().getMapContainer("Printers.netmap",false));
	//System.out.println("Symbol added  "+model.addSymbol(mSym, true));	
        //System.out.println("Symbol deleted  "+model.deleteSymbol(mSym, true));

        //MapGroupComponent mGrp = model.getSymbolByName("Sasik");

	 MapLinkComponent mLink = new MapLinkComponent();

	System.out.println(mLink);
        mapAPI.openMap("ipnet.netmap");
        //DefaultMapModel model = MapClientAPI.getInstance().getMapModel("ipnet.netmap");
          System.out.println("Attributes ====>  "+MapClientAPI.getInstance().getMapContainer("Switches.netmap",false));
          //System.out.println(model);
		//System.out.println("model symbol "+model.getMapObjects(true,true,true));


          //MapSymbolComponent sSym = model.getSymbolByName("192.168.4.0");
          //MapSymbolComponent sSym1 = model.getSymbolByKey("192.168.4.0\tipnet.netmap");
          //MapSymbolComponent dSym = model.getSymbolByName("203.199.211.64");

          //System.out.println(sSym);
          //System.out.println(dSym);
          /*
          mLink.setName("Sasik");
	  mLink.setLabel("MAR");
          mLink.setMenuName("snmpmenu.xml");
          mLink.setObjName("clarence");
          mLink.setMapName("ipnet.netmap");
          mLink.setSource("192.168.4.0");
	  mLink.setSourceObj(sSym);
          mLink.setDest("203.199.211.64");
	  mLink.setDestObj(dSym);
	  System.out.println(mLink);*/

          // System.out.println(model.addLink(mLink, true)); 

          //  MapGroupComponent mGrp = model.getGroupByName("Sasik");
		//	System.out.println(	model.addGroup(mGrp,true));
//	Properties p = new Properties();
//	p.put("Sasikumar", "kumar");
//		System.out.println(model.updateGroup("Sasik"+"\t"+"ipnet.netmap", p, true));

	//			System.out.println(model.getMapObjects(true,true,true));
	//			System.out.println(model.deleteGroup(mGrp, true));
	

/*        Properties p = new Properties();
	  p =  model.getMapCriteriaProperties();
	  System.out.println("---------------------------------------------");
	  System.out.println(p);

	  System.out.println("---------------------------------------------");
*/
	}
	public void internalFrameClosed(InternalFrameEvent e) 
	{
	}
    public void internalFrameClosing(InternalFrameEvent e) 
    {
    }
    public void internalFrameDeactivated(InternalFrameEvent e) 
    {
    }
    public void internalFrameDeiconified(InternalFrameEvent e) 
    {
    }
    public void internalFrameIconified(InternalFrameEvent e) 
    {
    }
    public void internalFrameOpened(InternalFrameEvent e) 
    {
    }

}//End of class ExampleNMSPanel





