#!/bin/sh
if [ $# = 4 ]
then
	PGSQL_HOME=$1
	PGSQL_SERVERNAME=$2
	PGSQL_PORT=$3
	PGSQL_USERNAME=$4
else
	echo Usage : sh pgsqlConsole.sh PGSQL_HOME PGSQL_SERVERNAME PGSQL_PORT PGSQL_USERNAME
	exit;
fi

$PGSQL_HOME/bin/psql -U $PGSQL_USERNAME -p $PGSQL_PORT -h $PGSQL_SERVERNAME

#$Id: pgsqlConsole.sh,v 1.4 2011/04/30 07:37:05 prabakaran Exp $
